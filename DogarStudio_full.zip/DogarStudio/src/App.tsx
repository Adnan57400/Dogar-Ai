import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Dashboard from "./components/Dashboard";
import LoginView from "./components/LoginView";
import OwnerDashboard from "./components/OwnerDashboard";
import ProfileView from "./components/ProfileView";
import SettingsView from "./components/SettingsView";
import AILabView from "./components/AILabView";
import VideoGenView from "./components/VideoGenView";

function App() {
  const [user, setUser] = useState<any>(null);

  return (
    <Router>
      <Routes>
        <Route path="/" element={user ? <Dashboard user={user} /> : <Navigate to="/login" />} />
        <Route path="/login" element={<LoginView setUser={setUser} />} />
        <Route path="/owner" element={user?.email === "adnannoordogar01@gmail.com" ? <OwnerDashboard /> : <Navigate to="/login" />} />
        <Route path="/profile" element={user ? <ProfileView user={user} /> : <Navigate to="/login" />} />
        <Route path="/settings" element={user ? <SettingsView user={user} /> : <Navigate to="/login" />} />
        <Route path="/ai-lab" element={user ? <AILabView /> : <Navigate to="/login" />} />
        <Route path="/video-gen" element={user ? <VideoGenView /> : <Navigate to="/login" />} />
      </Routes>
    </Router>
  );
}

export default App;