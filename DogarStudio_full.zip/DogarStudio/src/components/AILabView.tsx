import React, { useState } from "react";
import { generateImage } from "../services/aiStudioService";

const AILabView: React.FC = () => {
  const [prompt, setPrompt] = useState("");
  const [images, setImages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    const img = await generateImage(prompt);
    setImages([img.url!, ...images]);
    setLoading(false);
  };

  return (
    <div className="ai-lab">
      <h1>AI Lab</h1>
      <input placeholder="Enter prompt..." value={prompt} onChange={e => setPrompt(e.target.value)} />
      <button onClick={handleGenerate} disabled={loading}>{loading ? "Generating..." : "Generate Image"}</button>
      <div className="image-gallery">
        {images.map((url, i) => <img key={i} src={url} alt="AI Generated" />)}
      </div>
    </div>
  );
};

export default AILabView;