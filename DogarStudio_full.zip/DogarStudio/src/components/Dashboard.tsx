import React from "react";
import { Project } from "../types";

const sampleProjects: Project[] = [
  { id: "1", name: "Logo Design", progress: 70, status: "In Progress" },
  { id: "2", name: "Promo Video", progress: 20, status: "Pending" },
  { id: "3", name: "Website Redesign", progress: 100, status: "Completed" },
];

const Dashboard: React.FC<{ user: any }> = ({ user }) => {
  return (
    <div className="dashboard">
      <h1>Welcome, {user.name}</h1>
      <h2>Your Projects</h2>
      <div className="projects-grid">
        {sampleProjects.map(p => (
          <div key={p.id} className="project-card">
            <h3>{p.name}</h3>
            <div className="progress-bar-container">
              <div className="progress-bar" style={{ width: `${p.progress}%` }} />
            </div>
            <span>{p.status}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;