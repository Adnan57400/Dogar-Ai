import React, { useState } from "react";
import { User } from "../types";
import { v4 as uuidv4 } from "uuid";

interface Props {
  setUser: (user: User) => void;
}

const LoginView: React.FC<Props> = ({ setUser }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");

  const handleLogin = () => {
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    const user = users.find((u: User) => u.email === email && u.password === password);
    if (user) setUser(user);
    else setMessage("Invalid credentials");
  };

  const handleRegister = () => {
    let users = JSON.parse(localStorage.getItem("users") || "[]");
    if (users.find((u: User) => u.email === email)) return setMessage("Email already registered");
    const newUser = { id: uuidv4(), name, email, password, isPro: false };
    users.push(newUser);
    localStorage.setItem("users", JSON.stringify(users));
    setMessage("Registered successfully. Please login.");
    setIsRegister(false);
  };

  return (
    <div className="login-container">
      <h2>{isRegister ? "Register" : "Login"}</h2>
      {isRegister && <input placeholder="Name" value={name} onChange={e => setName(e.target.value)} />}
      <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
      <input placeholder="Password" type="password" value={password} onChange={e => setPassword(e.target.value)} />
      <button onClick={isRegister ? handleRegister : handleLogin}>{isRegister ? "Register" : "Login"}</button>
      <p onClick={() => setIsRegister(!isRegister)} style={{ cursor: "pointer", color: "blue" }}>
        {isRegister ? "Already have an account? Login" : "Don't have an account? Register"}
      </p>
      {message && <p style={{ color: "red" }}>{message}</p>}
    </div>
  );
};

export default LoginView;