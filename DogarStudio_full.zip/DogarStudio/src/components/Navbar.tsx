import React from "react";

const Navbar: React.FC = () => {
  return (
    <div className="navbar">
      <h1>Dogar Studio</h1>
    </div>
  );
};

export default Navbar;