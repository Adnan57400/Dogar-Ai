import React, { useState } from "react";

const OwnerDashboard: React.FC = () => {
  const [logs, setLogs] = useState<string[]>([]);
  const addLog = (msg: string) => setLogs(prev => [msg, ...prev]);

  return (
    <div className="owner-dashboard">
      <h1>Owner Command Center</h1>

      <div className="control-panel">
        <button onClick={() => addLog("Studio Locked")}>Lock Studio</button>
        <button onClick={() => addLog("All users upgraded to Pro")}>Mass Pro Upgrade</button>
        <button onClick={() => addLog("Neural Cache Purged")}>Purge Neural Cache</button>
        <button onClick={() => addLog("Broadcast Alert Sent")}>Broadcast Alert</button>
      </div>

      <div className="system-logs">
        <h2>Logs</h2>
        <div className="log-container">
          {logs.map((l, i) => (
            <div key={i} className="log-item">{l}</div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default OwnerDashboard;