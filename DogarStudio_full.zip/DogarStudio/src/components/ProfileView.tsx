import React, { useState } from "react";

interface Props {
  user: any;
}

const ProfileView: React.FC<Props> = ({ user }) => {
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);
  const [message, setMessage] = useState("");

  const handleSave = () => {
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    const idx = users.findIndex((u: any) => u.email === user.email);
    users[idx] = { ...users[idx], name, email };
    localStorage.setItem("users", JSON.stringify(users));
    setMessage("Profile updated!");
  };

  return (
    <div className="profile-view">
      <h1>My Profile</h1>
      <input value={name} onChange={e => setName(e.target.value)} />
      <input value={email} onChange={e => setEmail(e.target.value)} />
      <button onClick={handleSave}>Save</button>
      {message && <p>{message}</p>}
    </div>
  );
};

export default ProfileView;