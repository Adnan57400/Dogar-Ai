import React, { useState } from "react";

interface Props {
  user: any;
}

const SettingsView: React.FC<Props> = ({ user }) => {
  const [theme, setTheme] = useState("light");
  const [notifications, setNotifications] = useState(true);

  return (
    <div className="settings-view">
      <h1>Studio Settings</h1>
      <label>
        Theme:
        <select value={theme} onChange={e => setTheme(e.target.value)}>
          <option value="light">Light</option>
          <option value="dark">Dark</option>
        </select>
      </label>
      <label>
        Notifications:
        <input type="checkbox" checked={notifications} onChange={e => setNotifications(e.target.checked)} />
      </label>
    </div>
  );
};

export default SettingsView;