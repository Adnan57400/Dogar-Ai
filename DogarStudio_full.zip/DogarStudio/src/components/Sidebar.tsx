import React from "react";
import { Link } from "react-router-dom";

const Sidebar: React.FC = () => {
  return (
    <div className="sidebar">
      <h2>Dogar Studio</h2>
      <Link to="/">Dashboard</Link>
      <Link to="/profile">Profile</Link>
      <Link to="/settings">Settings</Link>
      <Link to="/ai-lab">AI Lab</Link>
      <Link to="/video-gen">Video Gen</Link>
      <Link to="/owner">Owner</Link>
    </div>
  );
};

export default Sidebar;