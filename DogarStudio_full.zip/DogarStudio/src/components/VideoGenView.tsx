import React, { useState } from "react";
import { generateVideo } from "../services/aiStudioService";

const VideoGenView: React.FC = () => {
  const [prompt, setPrompt] = useState("");
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    const result = await generateVideo(prompt);
    setVideoUrl(result.url || null);
    setLoading(false);
  };

  return (
    <div className="video-gen">
      <h1>Video Generation (Free API)</h1>
      <input placeholder="Enter video prompt..." value={prompt} onChange={e => setPrompt(e.target.value)} />
      <button onClick={handleGenerate} disabled={loading}>{loading ? "Generating..." : "Generate Video"}</button>
      {videoUrl && <video src={videoUrl} controls width={600} />}
    </div>
  );
};

export default VideoGenView;