import { v4 as uuidv4 } from "uuid";
import { ImageRequest, VideoRequest } from "../types";

export const generateImage = async (prompt: string): Promise<ImageRequest> => {
  const imageUrl = `https://via.placeholder.com/600x400.png?text=${encodeURIComponent(prompt)}`;
  return new Promise(resolve => setTimeout(() => resolve({ id: uuidv4(), prompt, url: imageUrl }), 1500));
};

export const generateVideo = async (prompt: string): Promise<VideoRequest> => {
  return new Promise(resolve =>
    setTimeout(
      () =>
        resolve({
          id: uuidv4(),
          prompt,
          status: "Done",
          url: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4"
        }),
      3000
    )
  );
};