export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  isPro?: boolean;
}

export interface Project {
  id: string;
  name: string;
  progress: number;
  status: "Pending" | "In Progress" | "Completed";
}

export interface VideoRequest {
  id: string;
  prompt: string;
  status: "Pending" | "Generating" | "Done";
  url?: string;
}

export interface ImageRequest {
  id: string;
  prompt: string;
  url?: string;
}